# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class customer_registeration_model(models.Model):

	user = models.OneToOneField(User)
	age = models.IntegerField(default=18)
	contact1 = models.IntegerField()
	contact2 = models.IntegerField()
	loaction = models.CharField(max_length=25)
	zip_code = models.IntegerField()
	created_on = models.DateTimeField(auto_now=True)


class MyWalletModal(models.Model):

	username = models.ForeignKey(User)
	product_name = models.CharField(max_length=50)
	size = models.IntegerField()
	amount = models.IntegerField()
	status = models.BooleanField(default=False)

