# -*- coding: utf-8 -*-

from __future__ import unicode_literals
from django.shortcuts import render,render_to_response,redirect
from django.views.generic import TemplateView,FormView,View
from django.core.urlresolvers import reverse_lazy
from django.http import HttpResponse
import json
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import auth
# Create your views here.

from django.contrib.auth.models import User
from form import UserForm,CustomerForm
from models import customer_registeration_model,MyWalletModal
from product.forms import ProductForm
from product.models import ProductModel,Stock,Categories

class HomeView(TemplateView):
	template_name = "index.html"
	def get(self,request):
		dict1={}
		usr=ProductModel.objects.all()

		dict1["test"]=usr
		return render(request,'index.html',dict1)

class MyOrderView(TemplateView):
	template_name = "myorder.html"

class AdminHome(View):
	template_name = "admin_index.html"
	form_class = ProductForm

	def get(self,request):
		form = self.form_class()
		# pro_code = random()
		context = {
			'f3': form,
		}
		return render(request, self.template_name, context)

class RegisterationView(FormView):

	template_name = "signup.html"
	form_class = UserForm

	def get(self,request,*args,**kwargs):

		print("&&&11")

		form_class = self.get_form_class()
		form1 = self.get_form(form_class)
		form2 = CustomerForm()
		print("&&&22")

		return self.render_to_response(self.get_context_data(f1=form1,f2=form2))

	def post(self,request,*args,**kwargs):

		print("&&&")
		form_class = self.get_form_class()
		form1 = self.get_form(form_class)
		form2 = CustomerForm(self.request.POST)
		print(form1,form2)
		if(form1.is_valid() and form2.is_valid()):
			return self.form_valid(form1,form2)
		else:
			return self.form_invalid(form1,form2)

	def form_valid(self,form1,form2):
		self.object = form1.save()
		self.object.staff = True 
		p = form2.save(commit=False)
		p.user = self.object
		p.save()

		return super(RegisterationView,self).form_valid(form2)

	def form_invalid(self,form1,form2):

		return self.render_to_response(self.get_context_data(f1=form1,f2=form2))

	def get_success_url(self,**kwargs):

		return reverse_lazy("customer_regiseraion")

class ChangePasswordView(View):

	def post(self,request):
		print("Hello_this")
		old = request.POST.get('old_password')
		new = request.POST.get('new_password')
		print(old, new)

		userobj = User.objects.get(username=request.user)
		
		if userobj.check_password(old):
			userobj.set_password(new)
			userobj.save()
			response="Success"

		else :
			print("Error")
			response="failed"

		return HttpResponse(json.dumps(response),content_type='json')

def login(request):
    form =AuthenticationForm()
    if request.user.is_authenticated():
        if request.user.is_superuser:
            return redirect("/adminhome/")# or your url name
        if request.user.is_staff:
            return redirect("/home/")# or your url name


    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = auth.authenticate(username=username, password=password)

        if user is not None:
            # correct username and password login the user
            auth.login(request, user)
            if request.user.is_superuser:
                return redirect("/adminhome/")# or your url name
            if request.user.is_staff:
                return redirect("/home/")# or your url name

        else:
            messages.error(request, 'Error wrong username/password')
    context = {}
    context['form']=form

    return render(request, 'registration/login.html', context)


class MyProductView1(View):
	def get(self,request):
		dict1={}

		category = Categories.objects.filter(category_title="Bottomwear")
		for x in category:
			print(x)

		usr=ProductModel.objects.filter(pdt_category=x)
		dict1["test"]=usr
		print(dict1)
		return render(request,'product.html',dict1)

class MyProductView2(View):
	def get(self,request):
		dict1={}
		category = Categories.objects.filter(category_title="Topwear")
		for x in category:
			print(x)

		usr=ProductModel.objects.filter(pdt_category=x)
		dict1["test"]=usr
		return render(request,'product.html',dict1)

class MyProductView3(View):
	def get(self,request):
		dict1={}
		category = Categories.objects.filter(category_title="Frocks")
		for x in category:
			print(x)

		usr=ProductModel.objects.filter(pdt_category=x)
		dict1["test"]=usr
		return render(request,'product.html',dict1)

class MyProductView4(View):
	def get(self,request):
		dict1={}
		category = Categories.objects.filter(category_title="Kids Accessories")
		for x in category:
			print(x)

		usr=ProductModel.objects.filter(pdt_category=x)
		dict1["test"]=usr
		return render(request,'product.html',dict1)

class MyWalletVew(View):
	def post(self,request,regid):
		amount = request.GET['amount_required']
		size = request.GET['size']

		product =  ProductModel.objects.get(product_name=regid)
		user = request.User.username
		MyWalletModal.username = user
		MyWalletModal.product_name = product.product_name
		MyWalletModal.size = size
		MyWalletModal.amount = amount

		return HttpResponse(json.dumps(response),content_type='json')
		


class ItemView(View):
	print("hello")


	def get(self,request,regid):
		dict1={}
		print("hello")
		usr=ProductModel.objects.get(product_name=regid)
		stocks_obj = Stock.objects.filter(stock_name=regid)
	
		dict1["test"]=usr
		dict1["stocks"]=stocks_obj
		return render(request,'single.html',dict1)

	def post(self,request,regid):
		product =  ProductModel.objects.get(product_name=regid)
		user = request.User.username
		return